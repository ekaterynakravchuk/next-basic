export default function NewPost() {
  return <h1>Create new post</h1>;
}
