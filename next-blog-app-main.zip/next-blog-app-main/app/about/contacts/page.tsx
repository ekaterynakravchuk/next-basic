export default function Contact() {
  return <h1>Contact page</h1>;
}
