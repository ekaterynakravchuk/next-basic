const TheFooter = () => {
  return <footer className="container">Created by &copy;MishaNep</footer>;
};

export { TheFooter };
