export default function LoadingPosts() {
  return <h1>Loading...</h1>;
}
