export default function Home() {
  return <h1>Welcome to NextJS world</h1>;
}
